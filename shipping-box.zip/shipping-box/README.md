# 📦 Shipping Box Calculator

A modern React application for calculating shipping costs from India to various international destinations. This application allows users to add shipping boxes with detailed information and automatically calculates shipping costs based on weight and destination country.

![React](https://img.shields.io/badge/React-18.3.1-61DAFB?style=flat-square&logo=react)
![JavaScript](https://img.shields.io/badge/JavaScript-ES6+-F7DF1E?style=flat-square&logo=javascript)
![CSS3](https://img.shields.io/badge/CSS3-Responsive-1572B6?style=flat-square&logo=css3)
![React Router](https://img.shields.io/badge/React_Router-6.x-CA4245?style=flat-square&logo=react-router)

## 🌟 Features

### Core Functionality
- ✅ **Add Box Form**: Complete form with validation for receiver name, weight, color, and destination
- ✅ **Box List Table**: Responsive table displaying all saved boxes with calculated shipping costs
- ✅ **Cost Calculation**: Automatic shipping cost calculation based on weight and destination
- ✅ **Color Visualization**: Visual color representation in the table with RGB values
- ✅ **Input Validation**: Comprehensive validation with user-friendly error messages
- ✅ **Responsive Design**: Mobile-first design that works on all device sizes

### Technical Features
- 🏗️ **MVC Architecture**: Clean separation of concerns with organized folder structure
- 🎯 **State Management**: Context API for global state management
- 🔄 **Client-side Routing**: Single Page Application with React Router
- 💾 **Local Storage**: Data persistence using browser local storage
- 🎨 **Modern UI**: Beautiful, accessible interface with CSS animations
- 📱 **Mobile Responsive**: Optimized for mobile, tablet, and desktop
- ⚡ **Performance**: Optimized rendering with React best practices

## 🚀 Quick Start

### Prerequisites
- Node.js (version 16.0 or higher)
- npm (version 8.0 or higher)

### Installation & Setup

1. **Clone the repository**
   ```bash
   git clone https://github.com/your-username/shipping-box-calculator.git
   cd shipping-box-calculator
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   - Copy the `.env` file and customize if needed
   - All environment variables are pre-configured with sensible defaults

4. **Start the development server**
   ```bash
   npm start
   ```

5. **Open your browser**
   - Navigate to [http://localhost:3000](http://localhost:3000)
   - The application will automatically reload when you make changes

### Build for Production

```bash
# Create optimized production build
npm run build

# The build files will be in the 'build' folder
# Ready for deployment to any static hosting service
```

## 📋 Available Scripts

### Development
- `npm start` - Runs the app in development mode
- `npm test` - Launches the test runner in interactive watch mode
- `npm run build` - Builds the app for production
- `npm run eject` - Ejects from Create React App (⚠️ irreversible)

## 🏗️ Project Architecture

### Folder Structure
```
src/
├── components/          # React components
│   ├── Navbar/         # Navigation component
│   ├── AddBox/         # Add box form component
│   └── BoxList/        # Box listing table component
├── context/            # Context API for state management
│   └── BoxContext.js   # Global box data context
├── services/           # Business logic and API simulation
│   └── boxService.js   # Box CRUD operations
├── utils/              # Utility functions
│   ├── shippingCalculator.js  # Shipping cost calculations
│   ├── validation.js   # Form validation logic
│   └── config.js       # Environment configuration
├── styles/             # Global styles
│   └── globals.css     # CSS variables and utilities
├── App.js              # Main application component
├── App.css             # Global application styles
└── index.js            # Application entry point
```

### Architecture Pattern
This application follows the **MVC (Model-View-Controller)** pattern:

- **Model**: Data management in `context/BoxContext.js` and `services/boxService.js`
- **View**: React components in `components/` folder with associated CSS files
- **Controller**: Business logic in `utils/` folder and component event handlers

### State Management
- **Context API**: Global state management for box data
- **Local State**: Component-level state for forms and UI interactions
- **Local Storage**: Data persistence across browser sessions

## 💡 Usage Guide

### Adding a New Box

1. Navigate to the **Add Box** page (default home page)
2. Fill in the required information:
   - **Receiver Name**: Full name of the recipient (2-50 characters)
   - **Weight**: Package weight in kilograms (positive numbers only)
   - **Box Color**: Use color picker or enter RGB values (e.g., "255, 0, 0")
   - **Destination**: Select from available countries (Sweden, China, Brazil, Australia)
3. Click **Save Box** to store the information
4. The shipping cost will be automatically calculated and displayed

### Viewing Box List

1. Navigate to **Box List** using the navigation menu
2. View all saved boxes in a sortable table
3. Use search and filter options to find specific boxes:
   - **Search**: Filter by receiver name
   - **Country Filter**: Show boxes for specific destinations
   - **Sort**: Click column headers to sort data
4. Each box displays:
   - Receiver name
   - Weight in kilograms
   - Visual color representation
   - Destination country with flag
   - Calculated shipping cost in INR
   - Date when the box was added

## 💰 Shipping Rates

Current shipping rates from India (per kilogram):

| Country   | Rate (INR/kg) | Flag |
|-----------|---------------|------|
| Sweden    | ₹7.35         | 🇸🇪   |
| China     | ₹11.53        | 🇨🇳   |
| Brazil    | ₹15.63        | 🇧🇷   |
| Australia | ₹50.09        | 🇦🇺   |

*Note: These rates can be configured via environment variables*

## 🔧 Configuration

### Environment Variables
The application uses environment variables for configuration. All variables in the `.env` file can be customized:

```env
# Shipping rates (configurable)
REACT_APP_RATE_SWEDEN=7.35
REACT_APP_RATE_CHINA=11.53
REACT_APP_RATE_BRAZIL=15.63
REACT_APP_RATE_AUSTRALIA=50.09

# Application settings
REACT_APP_MAX_WEIGHT_LIMIT=1000
REACT_APP_DEFAULT_CURRENCY=INR
REACT_APP_DECIMAL_PLACES=2
```

### Customization
- **Shipping Rates**: Update rates in `.env` file
- **Color Themes**: Modify CSS variables in `src/styles/globals.css`
- **Countries**: Add new countries in `utils/config.js`
- **Validation Rules**: Customize validation in `utils/validation.js`

## 📱 Responsive Design

The application is fully responsive and optimized for:

- **Mobile Phones** (320px - 480px): Stacked layout, simplified navigation
- **Tablets** (481px - 768px): Optimized spacing, condensed information
- **Desktop** (769px+): Full feature layout with optimal spacing

### Mobile Features
- Hamburger menu navigation
- Stacked form layout
- Card-based table display
- Touch-friendly interactions
- Optimized text sizes

## ⚡ Performance Features

- **Lazy Loading**: Components loaded on demand
- **Memoization**: Optimized re-renders with React.memo
- **Local Storage**: Fast data access without server calls
- **Efficient Updates**: Context API with selective updates
- **Optimized Builds**: Production builds with code splitting

## 🔒 Data Management

### Local Storage
- Data persists across browser sessions
- Automatic backup and recovery
- No server dependency for data storage
- Privacy-focused (data stays on user's device)

### Data Structure
```javascript
{
  id: "unique-identifier",
  receiverName: "John Doe",
  weight: 2.5,
  color: "255, 0, 0",
  destination: "Sweden",
  shippingCost: 18.38,
  createdAt: "2024-01-01T12:00:00.000Z",
  updatedAt: "2024-01-01T12:00:00.000Z"
}
```

## 🧪 Testing

```bash
# Run all tests
npm test

# Run tests in watch mode
npm test -- --watch

# Run tests with coverage
npm test -- --coverage
```

## 🚀 Deployment

### Static Hosting (Recommended)
```bash
# Build for production
npm run build

# Deploy to hosting platforms:
# - Netlify: drag & drop build folder
# - Vercel: connect GitHub repository
# - GitHub Pages: use gh-pages package
```

### Environment Setup for Production
1. Update `.env` with production values
2. Set `REACT_APP_DEV_MODE=false`
3. Configure analytics if needed
4. Test the production build locally: `npm run build && npx serve -s build`

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-feature`
3. Commit changes: `git commit -m 'Add amazing feature'`
4. Push to branch: `git push origin feature/amazing-feature`
5. Open a Pull Request

### Coding Standards
- Use functional components with hooks
- Follow ESLint configuration
- Add comments for complex logic
- Maintain responsive design
- Write tests for new features

## 📚 Learning Resources

### React Concepts Used
- **Functional Components**: Modern React component pattern
- **Hooks**: useState, useEffect, useContext, useReducer
- **Context API**: Global state management
- **React Router**: Client-side routing
- **Event Handling**: Form submissions and user interactions

### CSS Techniques
- **Flexbox & Grid**: Modern layout techniques
- **CSS Variables**: Consistent theming
- **Media Queries**: Responsive design
- **Animations**: Smooth user interactions
- **Accessibility**: ARIA attributes and keyboard navigation

## 🐛 Troubleshooting

### Common Issues

**Application won't start:**
```bash
# Clear npm cache
npm cache clean --force

# Delete node_modules and reinstall
rm -rf node_modules package-lock.json
npm install
```

**Build fails:**
```bash
# Check Node.js version (should be 16+)
node --version

# Update dependencies
npm update
```

**Styling issues:**
- Clear browser cache
- Check CSS import statements
- Verify CSS variables are loaded

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🏆 Acknowledgments

- React team for the amazing framework
- Create React App for the boilerplate
- Modern CSS techniques and best practices
- Accessibility guidelines and standards

---

**Built with ❤️ using React.js**

For support or questions, please open an issue in the GitHub repository.

### `npm run eject`

**Note: this is a one-way operation. Once you `eject`, you can't go back!**

If you aren't satisfied with the build tool and configuration choices, you can `eject` at any time. This command will remove the single build dependency from your project.

Instead, it will copy all the configuration files and the transitive dependencies (webpack, Babel, ESLint, etc) right into your project so you have full control over them. All of the commands except `eject` will still work, but they will point to the copied scripts so you can tweak them. At this point you're on your own.

You don't have to ever use `eject`. The curated feature set is suitable for small and middle deployments, and you shouldn't feel obligated to use this feature. However we understand that this tool wouldn't be useful if you couldn't customize it when you are ready for it.

## Learn More

You can learn more in the [Create React App documentation](https://facebook.github.io/create-react-app/docs/getting-started).

To learn React, check out the [React documentation](https://reactjs.org/).

### Code Splitting

This section has moved here: [https://facebook.github.io/create-react-app/docs/code-splitting](https://facebook.github.io/create-react-app/docs/code-splitting)

### Analyzing the Bundle Size

This section has moved here: [https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size](https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size)

### Making a Progressive Web App

This section has moved here: [https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app](https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app)

### Advanced Configuration

This section has moved here: [https://facebook.github.io/create-react-app/docs/advanced-configuration](https://facebook.github.io/create-react-app/docs/advanced-configuration)

### Deployment

This section has moved here: [https://facebook.github.io/create-react-app/docs/deployment](https://facebook.github.io/create-react-app/docs/deployment)

### `npm run build` fails to minify

This section has moved here: [https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify](https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify)
