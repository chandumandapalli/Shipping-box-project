// Service layer for box data operations with localStorage persistence
import { calculateShippingCost } from '../utils/shippingCalculator';

const STORAGE_KEY = 'shipping_boxes';

const simulateDelay = (ms = 300) => {
  return new Promise(resolve => setTimeout(resolve, ms));
};

const generateId = () => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

const getCurrentTimestamp = () => {
  return new Date().toISOString();
};

export const boxService = {
  // Get all boxes from localStorage
  getAllBoxes: async () => {
    try {
      await simulateDelay();
      
      const storedBoxes = localStorage.getItem(STORAGE_KEY);
      const boxes = storedBoxes ? JSON.parse(storedBoxes) : [];
      
      return boxes.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
      
    } catch (error) {
      console.error('Error fetching boxes:', error);
      throw new Error('Failed to fetch boxes from storage');
    }
  },

  // Save a new box with calculated shipping cost
  saveBox: async (boxData) => {
    try {
      await simulateDelay();
      
      if (!boxData.receiverName || !boxData.weight || !boxData.color || !boxData.destination) {
        throw new Error('All fields are required');
      }

      const shippingCost = calculateShippingCost(boxData.weight, boxData.destination);
      
      const newBox = {
        id: generateId(),
        receiverName: boxData.receiverName.trim(),
        weight: parseFloat(boxData.weight),
        color: boxData.color.trim(),
        destination: boxData.destination,
        shippingCost: shippingCost,
        createdAt: getCurrentTimestamp(),
        updatedAt: getCurrentTimestamp(),
      };

      const existingBoxes = await boxService.getAllBoxes();
      const updatedBoxes = [newBox, ...existingBoxes];
      
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedBoxes));
      
      return newBox;
      
    } catch (error) {
      console.error('Error saving box:', error);
      throw new Error(`Failed to save box: ${error.message}`);
    }
  },

  getBoxById: async (id) => {
    try {
      await simulateDelay();
      
      const boxes = await boxService.getAllBoxes();
      const box = boxes.find(box => box.id === id);
      
      return box || null;
      
    } catch (error) {
      console.error('Error fetching box:', error);
      throw new Error('Failed to fetch box');
    }
  },

  deleteBox: async (id) => {
    try {
      await simulateDelay();
      
      const existingBoxes = await boxService.getAllBoxes();
      const updatedBoxes = existingBoxes.filter(box => box.id !== id);
      
      const wasDeleted = existingBoxes.length !== updatedBoxes.length;
      
      if (wasDeleted) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedBoxes));
      }
      
      return wasDeleted;
      
    } catch (error) {
      console.error('Error deleting box:', error);
      throw new Error('Failed to delete box');
    }
  },

  clearAllBoxes: async () => {
    try {
      await simulateDelay();
      localStorage.removeItem(STORAGE_KEY);
      
    } catch (error) {
      console.error('Error clearing boxes:', error);
      throw new Error('Failed to clear boxes');
    }
  },

  // Get statistics about boxes for dashboard
  getBoxStatistics: async () => {
    try {
      const boxes = await boxService.getAllBoxes();
      
      const totalBoxes = boxes.length;
      const totalWeight = boxes.reduce((sum, box) => sum + box.weight, 0);
      const totalShippingCost = boxes.reduce((sum, box) => sum + box.shippingCost, 0);
      
      const destinationStats = boxes.reduce((stats, box) => {
        stats[box.destination] = (stats[box.destination] || 0) + 1;
        return stats;
      }, {});
      
      return {
        totalBoxes,
        totalWeight: parseFloat(totalWeight.toFixed(2)),
        totalShippingCost: parseFloat(totalShippingCost.toFixed(2)),
        destinationStats,
      };
      
    } catch (error) {
      console.error('Error fetching statistics:', error);
      throw new Error('Failed to fetch statistics');
    }
  }
};