// Configuration utility for environment variables and app settings
const config = {
  app: {
    name: process.env.REACT_APP_NAME || 'Shipping Box Calculator',
    version: process.env.REACT_APP_VERSION || '1.0.0',
    description: process.env.REACT_APP_DESCRIPTION || 'Calculate shipping costs from India worldwide',
  },

  settings: {
    defaultCurrency: process.env.REACT_APP_DEFAULT_CURRENCY || 'INR',
    defaultWeightUnit: process.env.REACT_APP_DEFAULT_WEIGHT_UNIT || 'kg',
    maxWeightLimit: parseInt(process.env.REACT_APP_MAX_WEIGHT_LIMIT) || 1000,
    decimalPlaces: parseInt(process.env.REACT_APP_DECIMAL_PLACES) || 2,
  },

  features: {
    debugMode: process.env.REACT_APP_ENABLE_DEBUG_MODE === 'true',
    analytics: process.env.REACT_APP_ENABLE_ANALYTICS === 'true',
    serviceWorker: process.env.REACT_APP_ENABLE_SERVICE_WORKER === 'true',
  },

  api: {
    baseUrl: process.env.REACT_APP_API_BASE_URL || 'http://localhost:3001/api',
    timeout: parseInt(process.env.REACT_APP_API_TIMEOUT) || 10000,
    retryAttempts: parseInt(process.env.REACT_APP_API_RETRY_ATTEMPTS) || 3,
  },

  storage: {
    key: process.env.REACT_APP_STORAGE_KEY || 'shipping_boxes',
    enableLocalStorage: process.env.REACT_APP_ENABLE_LOCAL_STORAGE !== 'false',
    encryption: process.env.REACT_APP_STORAGE_ENCRYPTION === 'true',
  },

  ui: {
    theme: process.env.REACT_APP_THEME || 'light',
    defaultLanguage: process.env.REACT_APP_DEFAULT_LANGUAGE || 'en',
    itemsPerPage: parseInt(process.env.REACT_APP_ITEMS_PER_PAGE) || 10,
    animationDuration: parseInt(process.env.REACT_APP_ANIMATION_DURATION) || 300,
  },

  // Shipping rates (INR per kg)
  shippingRates: {
    Sweden: parseFloat(process.env.REACT_APP_RATE_SWEDEN) || 7.35,
    China: parseFloat(process.env.REACT_APP_RATE_CHINA) || 11.53,
    Brazil: parseFloat(process.env.REACT_APP_RATE_BRAZIL) || 15.63,
    Australia: parseFloat(process.env.REACT_APP_RATE_AUSTRALIA) || 50.09,
  },

  contact: {
    supportEmail: process.env.REACT_APP_SUPPORT_EMAIL || 'support@shippingcalculator.com',
    companyName: process.env.REACT_APP_COMPANY_NAME || 'Shipping Solutions Inc.',
  },

  development: {
    devMode: process.env.REACT_APP_DEV_MODE === 'true',
    showConsoleLogs: process.env.REACT_APP_SHOW_CONSOLE_LOGS === 'true',
    nodeEnv: process.env.NODE_ENV || 'development',
  },
};

// Utility functions
export const getShippingRate = (country) => {
  return config.shippingRates[country] || 0;
};

export const getAvailableCountries = () => {
  return Object.keys(config.shippingRates);
};

export const isFeatureEnabled = (featureName) => {
  return config.features[featureName] || false;
};

export const getAppInfo = () => {
  return {
    name: config.app.name,
    version: config.app.version,
    description: config.app.description,
  };
};

export const getEnvironment = () => {
  return config.development.nodeEnv;
};

export const isDevelopment = () => {
  return config.development.nodeEnv === 'development';
};

export const isProduction = () => {
  return config.development.nodeEnv === 'production';
};

export const logConfig = () => {
  if (isDevelopment() && config.development.showConsoleLogs) {
    console.group('📋 Application Configuration');
    console.log('App Info:', config.app);
    console.log('Settings:', config.settings);
    console.log('Features:', config.features);
    console.log('Shipping Rates:', config.shippingRates);
    console.log('Environment:', config.development.nodeEnv);
    console.groupEnd();
  }
};

export const validateConfig = () => {
  const errors = [];

  Object.entries(config.shippingRates).forEach(([country, rate]) => {
    if (isNaN(rate) || rate <= 0) {
      errors.push(`Invalid shipping rate for ${country}: ${rate}`);
    }
  });

  if (config.settings.maxWeightLimit <= 0) {
    errors.push(`Invalid max weight limit: ${config.settings.maxWeightLimit}`);
  }

  if (config.settings.decimalPlaces < 0 || config.settings.decimalPlaces > 4) {
    errors.push(`Invalid decimal places: ${config.settings.decimalPlaces}`);
  }

  if (config.api.timeout < 1000 || config.api.timeout > 60000) {
    errors.push(`Invalid API timeout: ${config.api.timeout}ms`);
  }

  if (errors.length > 0 && isDevelopment()) {
    console.error('⚠️ Configuration Validation Errors:', errors);
  }

  return errors.length === 0;
};

export default config;