// utils/index.js - Central export file for all utility functions
// This file makes it easier to import utilities from other parts of the application

// Export all utility functions
export * from './shippingCalculator';
export * from './validation';
export { default as config } from './config';

// Named exports for better organization
export {
  calculateShippingCost,
  formatCurrency,
  getDestinationCountries,
  parseRGBColor,
  rgbToHex,
  isValidRGBColor
} from './shippingCalculator';

export {
  validateReceiverName,
  validateWeight,
  validateColor,
  validateDestination,
  validateBoxForm
} from './validation';

export {
  getShippingRate,
  getAvailableCountries,
  isFeatureEnabled,
  getAppInfo,
  getEnvironment,
  isDevelopment,
  isProduction,
  logConfig,
  validateConfig
} from './config';

// This allows clean imports like:
// import { calculateShippingCost, validateBoxForm, config } from '../utils';