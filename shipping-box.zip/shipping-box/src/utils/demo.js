// demo.js - Demo data for testing the application
// This file contains sample data that can be used for testing and demonstration

// Demo boxes data for testing
export const demoBoxes = [
  {
    id: 'demo-1',
    receiverName: 'John Smith',
    weight: 2.5,
    color: '255, 0, 0',
    destination: 'Sweden',
    shippingCost: 18.38,
    createdAt: '2024-01-15T10:30:00.000Z',
    updatedAt: '2024-01-15T10:30:00.000Z'
  },
  {
    id: 'demo-2',
    receiverName: 'Maria Garcia',
    weight: 1.2,
    color: '0, 255, 0',
    destination: 'Brazil',  
    shippingCost: 18.76,
    createdAt: '2024-01-14T14:20:00.000Z',
    updatedAt: '2024-01-14T14:20:00.000Z'
  },
  {
    id: 'demo-3',
    receiverName: 'Li Wei',
    weight: 3.8,
    color: '0, 0, 255',
    destination: 'China',
    shippingCost: 43.81,
    createdAt: '2024-01-13T09:15:00.000Z',
    updatedAt: '2024-01-13T09:15:00.000Z'
  },
  {
    id: 'demo-4',
    receiverName: 'Sarah Johnson',
    weight: 0.8,
    color: '255, 255, 0',
    destination: 'Australia',
    shippingCost: 40.07,
    createdAt: '2024-01-12T16:45:00.000Z',
    updatedAt: '2024-01-12T16:45:00.000Z'
  },
  {
    id: 'demo-5',
    receiverName: 'Ahmed Hassan',
    weight: 5.2,
    color: '128, 0, 128',
    destination: 'Sweden',
    shippingCost: 38.22,
    createdAt: '2024-01-11T11:30:00.000Z',
    updatedAt: '2024-01-11T11:30:00.000Z'
  }
];

// Function to load demo data into localStorage
export const loadDemoData = () => {
  try {
    const existingData = localStorage.getItem('shipping_boxes');
    if (!existingData || JSON.parse(existingData).length === 0) {
      localStorage.setItem('shipping_boxes', JSON.stringify(demoBoxes));
      console.log('📦 Demo data loaded successfully!');
      return true;
    }
    console.log('📦 Existing data found, demo data not loaded');
    return false;
  } catch (error) {
    console.error('❌ Error loading demo data:', error);
    return false;
  }
};

// Function to clear all data
export const clearAllData = () => {
  try {
    localStorage.removeItem('shipping_boxes');
    console.log('🗑️ All data cleared successfully!');
    return true;
  } catch (error) {
    console.error('❌ Error clearing data:', error);
    return false;
  }
};

// Function to reset to demo data (clear existing and load demo)
export const resetToDemoData = () => {
  try {
    clearAllData();
    localStorage.setItem('shipping_boxes', JSON.stringify(demoBoxes));
    console.log('🔄 Reset to demo data successfully!');
    return true;
  } catch (error) {
    console.error('❌ Error resetting to demo data:', error);
    return false;
  }
};

// Export demo utilities for development
export const demoUtils = {
  loadDemoData,
  clearAllData,
  resetToDemoData,
  demoBoxes
};

// Auto-load demo data in development mode (if no existing data)
if (process.env.NODE_ENV === 'development') {
  // Only auto-load if there's no existing data
  const existingData = localStorage.getItem('shipping_boxes');
  if (!existingData) {
    loadDemoData();
  }
}