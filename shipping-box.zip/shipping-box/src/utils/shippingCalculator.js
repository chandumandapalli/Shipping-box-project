// Utility functions for calculating shipping costs and formatting
import config, { getShippingRate, getAvailableCountries } from './config';

export const SHIPPING_RATES = config.shippingRates;

export const getDestinationCountries = () => {
  return getAvailableCountries();
};

// Calculate shipping cost based on weight and destination
export const calculateShippingCost = (weight, destination) => {
  const rate = getShippingRate(destination);
  
  if (rate === 0) {
    throw new Error(`Shipping rate not found for destination: ${destination}`);
  }

  if (weight < 0) {
    throw new Error('Weight cannot be negative');
  }

  const cost = weight * rate;
  const decimalPlaces = config.settings.decimalPlaces;
  return parseFloat(cost.toFixed(decimalPlaces));
};

export const formatCurrency = (cost) => {
  return `₹${cost.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
};

export const isValidRGBColor = (colorString) => {
  const rgbRegex = /^rgb\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*\)$|^(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})$/;
  return rgbRegex.test(colorString);
};

// Convert RGB values to hex format for color display
export const rgbToHex = (r, g, b) => {
  const toHex = (n) => {
    const hex = parseInt(n).toString(16);
    return hex.length === 1 ? '0' + hex : hex;
  };
  
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
};

// Parse RGB string to get individual color values
export const parseRGBColor = (rgbString) => {
  if (!rgbString) return null;

  const cleanString = rgbString.trim();
  const match = cleanString.match(/^rgb\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*\)$|^(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})$/);
  
  if (!match) return null;

  const r = parseInt(match[1] || match[4]);
  const g = parseInt(match[2] || match[5]);
  const b = parseInt(match[3] || match[6]);

  if (r < 0 || r > 255 || g < 0 || g > 255 || b < 0 || b > 255) {
    return null;
  }

  return { r, g, b };
};