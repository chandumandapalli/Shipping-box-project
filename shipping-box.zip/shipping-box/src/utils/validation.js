// Form validation utilities
export const validateReceiverName = (name) => {
  if (!name || name.trim().length === 0) {
    return {
      isValid: false,
      message: 'Receiver name is required'
    };
  }

  if (name.trim().length < 2) {
    return {
      isValid: false,
      message: 'Receiver name must be at least 2 characters long'
    };
  }

  if (name.trim().length > 50) {
    return {
      isValid: false,
      message: 'Receiver name must be less than 50 characters'
    };
  }

  const nameRegex = /^[a-zA-Z\s\-'.]+$/;
  if (!nameRegex.test(name.trim())) {
    return {
      isValid: false,
      message: 'Receiver name can only contain letters, spaces, hyphens, and apostrophes'
    };
  }

  return {
    isValid: true,
    message: ''
  };
};

export const validateWeight = (weight) => {
  const numericWeight = typeof weight === 'string' ? parseFloat(weight) : weight;

  if (isNaN(numericWeight)) {
    return {
      isValid: false,
      message: 'Weight must be a valid number',
      value: 0
    };
  }

  if (numericWeight < 0) {
    return {
      isValid: false,
      message: 'Negative values are not permitted. Weight has been set to zero.',
      value: 0
    };
  }

  if (numericWeight === 0) {
    return {
      isValid: false,
      message: 'Weight must be greater than zero',
      value: 0
    };
  }

  if (numericWeight > 1000) {
    return {
      isValid: false,
      message: 'Weight cannot exceed 1000 kg',
      value: numericWeight
    };
  }

  const decimalPlaces = (numericWeight.toString().split('.')[1] || '').length;
  if (decimalPlaces > 2) {
    return {
      isValid: false,
      message: 'Weight can have maximum 2 decimal places',
      value: parseFloat(numericWeight.toFixed(2))
    };
  }

  return {
    isValid: true,
    message: '',
    value: numericWeight
  };
};

export const validateColor = (color) => {
  if (!color || color.trim().length === 0) {
    return {
      isValid: false,
      message: 'Box color is required'
    };
  }

  const cleanColor = color.trim();
  const rgbRegex = /^rgb\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*\)$|^(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})$/;
  const match = cleanColor.match(rgbRegex);

  if (!match) {
    return {
      isValid: false,
      message: 'Color must be in RGB format: "255, 255, 255" or "rgb(255, 255, 255)"'
    };
  }

  const r = parseInt(match[1] || match[4]);
  const g = parseInt(match[2] || match[5]);
  const b = parseInt(match[3] || match[6]);

  if (r < 0 || r > 255 || g < 0 || g > 255 || b < 0 || b > 255) {
    return {
      isValid: false,
      message: 'RGB values must be between 0 and 255'
    };
  }

  return {
    isValid: true,
    message: ''
  };
};

export const validateDestination = (destination) => {
  const validDestinations = ['Sweden', 'China', 'Brazil', 'Australia'];

  if (!destination || destination.trim().length === 0) {
    return {
      isValid: false,
      message: 'Destination country is required'
    };
  }

  if (!validDestinations.includes(destination.trim())) {
    return {
      isValid: false,
      message: 'Please select a valid destination country'
    };
  }

  return {
    isValid: true,
    message: ''
  };
};

// Validate entire form data
export const validateBoxForm = (formData) => {
  const errors = {};
  let isValid = true;

  const nameValidation = validateReceiverName(formData.receiverName);
  if (!nameValidation.isValid) {
    errors.receiverName = nameValidation.message;
    isValid = false;
  }

  const weightValidation = validateWeight(formData.weight);
  if (!weightValidation.isValid) {
    errors.weight = weightValidation.message;
    isValid = false;
  }

  const colorValidation = validateColor(formData.color);
  if (!colorValidation.isValid) {
    errors.color = colorValidation.message;
    isValid = false;
  }

  const destinationValidation = validateDestination(formData.destination);
  if (!destinationValidation.isValid) {
    errors.destination = destinationValidation.message;
    isValid = false;
  }

  return {
    isValid,
    errors
  };
};