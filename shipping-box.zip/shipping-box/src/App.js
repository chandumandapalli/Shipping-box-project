// Main application component with routing and global context
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { BoxProvider } from './context/BoxContext';
import Navbar from './components/Navbar/Navbar';
import Home from './components/Home/Home';
import AddBox from './components/AddBox/AddBox';
import BoxList from './components/BoxList/BoxList';
import './App.css';

function App() {
  return (
    <Router>
      <BoxProvider>
        <div className="App">
          <Navbar />
          <main className="main-content" role="main">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/add-box" element={<AddBox />} />
              <Route path="/box-list" element={<BoxList />} />
              <Route path="/boxes" element={<BoxList />} />
              <Route path="*" element={<Home />} />
            </Routes>
          </main>
          <footer className="app-footer" role="contentinfo">
            <div className="footer-content">
              <p className="footer-text">
                📦 Shipping Box Calculator - Calculate shipping costs from India worldwide
              </p>
            </div>
          </footer>
        </div>
      </BoxProvider>
    </Router>
  );
}

export default App;
