// components/index.js - Central export file for all components
// This file makes it easier to import components from other parts of the application

// Export all components from their respective folders
export { default as Navbar } from './Navbar/Navbar';
export { default as Home } from './Home/Home';
export { default as AddBox } from './AddBox/AddBox';
export { default as BoxList } from './BoxList/BoxList';

// This allows imports like:
// import { Navbar, Home, AddBox, BoxList } from '../components';
// instead of:
// import Navbar from '../components/Navbar/Navbar';
// import AddBox from '../components/AddBox/AddBox';
// import BoxList from '../components/BoxList/BoxList';