// Form component for adding new shipping boxes with validation
import React, { useState } from 'react';
import { useBox } from '../../context/BoxContext';
import { validateBoxForm } from '../../utils/validation';
import { getDestinationCountries } from '../../utils/shippingCalculator';
import './AddBox.css';

const AddBox = () => {
  const { addBox, loading, error, clearError } = useBox();

  const [formData, setFormData] = useState({
    receiverName: '',
    weight: '',
    color: '',
    destination: ''
  });

  const [formErrors, setFormErrors] = useState({});
  const [successMessage, setSuccessMessage] = useState('');

  const destinationCountries = getDestinationCountries();

  const handleInputChange = (e) => {
    const { name, value } = e.target;

    // Handle negative weight validation
    if (name === 'weight') {
      if (parseFloat(value) < 0) {
        setFormErrors(prev => ({
          ...prev,
          weight: 'Negative values are not permitted. Weight has been set to zero.'
        }));
        setFormData(prev => ({ ...prev, [name]: '0' }));
        return;
      } else {
        setFormErrors(prev => ({ ...prev, weight: '' }));
      }
    }

    setFormData(prev => ({ ...prev, [name]: value }));
    
    if (formErrors[name]) {
      setFormErrors(prev => ({ ...prev, [name]: '' }));
    }
    
    if (successMessage) {
      setSuccessMessage('');
    }
    
    if (error) {
      clearError();
    }
  };

  // Convert hex color to RGB format
  const handleColorChange = (e) => {
    const hexColor = e.target.value;
    
    const rgb = hexToRgb(hexColor);
    if (rgb) {
      const rgbString = `${rgb.r}, ${rgb.g}, ${rgb.b}`;
      setFormData(prev => ({ ...prev, color: rgbString }));
      
      if (formErrors.color) {
        setFormErrors(prev => ({ ...prev, color: '' }));
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    setSuccessMessage('');
    if (error) clearError();

    const validation = validateBoxForm(formData);
    
    if (!validation.isValid) {
      setFormErrors(validation.errors);
      return;
    }

    setFormErrors({});

    try {
      const result = await addBox(formData);
      
      if (result.success) {
        setSuccessMessage('Box added successfully! 🎉');
        
        setFormData({
          receiverName: '',
          weight: '',
          color: '',
          destination: ''
        });

        setTimeout(() => {
          setSuccessMessage('');
        }, 3000);
      }
    } catch (err) {
      console.error('Error adding box:', err);
    }
  };

  const handleReset = () => {
    setFormData({
      receiverName: '',
      weight: '',
      color: '',
      destination: ''
    });
    setFormErrors({});
    setSuccessMessage('');
    if (error) clearError();
  };

  return (
    <div className="add-box-container">
      <div className="add-box-header">
        <h2 className="add-box-title">📦 Add New Shipping Box</h2>
        <p className="add-box-description">
          Fill in the details below to calculate shipping costs and save the box information.
        </p>
      </div>

      {successMessage && (
        <div className="success-message" role="alert">
          {successMessage}
        </div>
      )}

      {error && (
        <div className="error-message" role="alert">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="add-box-form" noValidate>
        <div className="form-group">
          <label htmlFor="receiverName" className="form-label">
            Receiver Name 
          </label>
          <input
            type="text"
            id="receiverName"
            name="receiverName"
            value={formData.receiverName}
            onChange={handleInputChange}
            className={`form-input ${formErrors.receiverName ? 'error' : ''}`}
            placeholder="Enter receiver's full name"
            maxLength="50"
            aria-describedby={formErrors.receiverName ? 'receiverName-error' : undefined}
            required
          />
          {formErrors.receiverName && (
            <div id="receiverName-error" className="field-error" role="alert">
              {formErrors.receiverName}
            </div>
          )}
        </div>

        <div className="form-group">
          <label htmlFor="weight" className="form-label">
            Weight (kg) 
          </label>
          <input
            type="number"
            id="weight"
            name="weight"
            value={formData.weight}
            onChange={handleInputChange}
            className={`form-input ${formErrors.weight ? 'error' : ''}`}
            placeholder="Enter weight in kilograms"
            min="0"
            step="0.01"
            max="1000"
            aria-describedby={formErrors.weight ? 'weight-error' : undefined}
            required
          />
          {formErrors.weight && (
            <div id="weight-error" className="field-error" role="alert">
              {formErrors.weight}
            </div>
          )}
        </div>

        <div className="form-group">
          <label htmlFor="color" className="form-label">
            Box Color 
          </label>
          <div className="color-input-group">
            <input
              type="color"
              id="colorPicker"
              onChange={handleColorChange}
              className="color-picker"
              aria-label="Select box color"
            />
            
            <input
              type="text"
              id="color"
              name="color"
              value={formData.color}
              onChange={handleInputChange}
              className={`form-input color-text-input ${formErrors.color ? 'error' : ''}`}
              placeholder="RGB format: 255, 255, 255"
              aria-describedby={formErrors.color ? 'color-error' : undefined}
              required
            />
          </div>
          <div className="color-hint">
            Use the color picker or enter RGB values manually (e.g., "255, 0, 0" for red)
          </div>
          {formErrors.color && (
            <div id="color-error" className="field-error" role="alert">
              {formErrors.color}
            </div>
          )}
        </div>

        <div className="form-group">
          <label htmlFor="destination" className="form-label">
            Destination Country 
          </label>
          <select
            id="destination"
            name="destination"
            value={formData.destination}
            onChange={handleInputChange}
            className={`form-select ${formErrors.destination ? 'error' : ''}`}
            aria-describedby={formErrors.destination ? 'destination-error' : undefined}
            required
          >
            <option value="">Select destination country</option>
            {destinationCountries.map(country => (
              <option key={country} value={country}>
                {country}
              </option>
            ))}
          </select>
          {formErrors.destination && (
            <div id="destination-error" className="field-error" role="alert">
              {formErrors.destination}
            </div>
          )}
        </div>

        <div className="form-actions">
          <button
            type="submit"
            className="btn btn-primary"
            disabled={loading}
          >
            {loading ? (
              <>
                <span className="loading-spinner" aria-hidden="true"></span>
                Saving...
              </>
            ) : (
              <>
                <span aria-hidden="true">💾</span>
                Save Box
              </>
            )}
          </button>
          
          <button
            type="button"
            onClick={handleReset}
            className="btn btn-secondary"
            disabled={loading}
          >
            <span aria-hidden="true">🔄</span>
            Reset Form
          </button>
        </div>
      </form>
    </div>
  );
};

// Helper function to convert hex color to RGB
const hexToRgb = (hex) => {
  hex = hex.replace('#', '');
  
  const r = parseInt(hex.substr(0, 2), 16);
  const g = parseInt(hex.substr(2, 2), 16);
  const b = parseInt(hex.substr(4, 2), 16);
  
  if (isNaN(r) || isNaN(g) || isNaN(b)) {
    return null;
  }
  
  return { r, g, b };
};

export default AddBox;