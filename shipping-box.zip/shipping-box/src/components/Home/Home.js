// Welcome page with features and how-it-works sections
import React from 'react';
import { Link } from 'react-router-dom';
import './Home.css';

const Home = () => {
  return (
    <div className="home-container">
      <section className="hero-section">
        <div className="hero-content">
          <h1 className="hero-title">
            Welcome to Cost Shipping Calculator
          </h1>
          <p className="hero-description">
            Your ultimate solution for calculating accurate shipping costs from India to worldwide destinations. 
            Get instant quotes, manage your shipments, and track your shipping boxes with ease.
          </p>
          
          <div className="hero-actions">
            <Link to="/add-box" className="btn btn-primary">
              📦 Calculate Shipping Cost
            </Link>
            <Link to="/box-list" className="btn btn-secondary">
              📋 View Your Boxes
            </Link>
          </div>
        </div>
      </section>

      <section className="features-section">
        <div className="features-container">
          <h2 className="features-title">Why Choose Our Shipping Calculator?</h2>
          
          <div className="features-grid">
            <div className="feature-card">
              <div className="feature-icon">🌍</div>
              <h3 className="feature-title">Worldwide Shipping</h3>
              <p className="feature-description">
                Calculate shipping costs to any destination across the globe from India. 
                We support all major international shipping routes.
              </p>
            </div>

            <div className="feature-card">
              <div className="feature-icon">💰</div>
              <h3 className="feature-title">Accurate Pricing</h3>
              <p className="feature-description">
                Get precise shipping cost calculations based on box dimensions, weight, 
                and destination. No hidden fees or surprise charges.
              </p>
            </div>

            <div className="feature-card">
              <div className="feature-icon">⚡</div>
              <h3 className="feature-title">Instant Results</h3>
              <p className="feature-description">
                Receive immediate shipping cost estimates. Quick calculations help you 
                make informed decisions for your shipments.
              </p>
            </div>

            <div className="feature-card">
              <div className="feature-icon">📊</div>
              <h3 className="feature-title">Box Management</h3>
              <p className="feature-description">
                Keep track of all your shipping boxes in one place. View, edit, and 
                manage your shipment history with our intuitive interface.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="how-it-works-section">
        <div className="how-it-works-container">
          <h2 className="section-title">How It Works</h2>
          
          <div className="steps-container">
            <div className="step-item">
              <div className="step-number">1</div>
              <div className="step-content">
                <h3 className="step-title">Enter Box Details</h3>
                <p className="step-description">
                  Provide your box dimensions, weight, and destination country to get started.
                </p>
              </div>
            </div>

            <div className="step-item">
              <div className="step-number">2</div>
              <div className="step-content">
                <h3 className="step-title">Get Instant Quote</h3>
                <p className="step-description">
                  Our calculator instantly computes the shipping cost based on your inputs.
                </p>
              </div>
            </div>

            <div className="step-item">
              <div className="step-number">3</div>
              <div className="step-content">
                <h3 className="step-title">Save & Track</h3>
                <p className="step-description">
                  Save your shipment details and track all your boxes in the Box List view.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="cta-section">
        <div className="cta-container">
          <h2 className="cta-title">Ready to Calculate Your Shipping Costs?</h2>
          <p className="cta-description">
            Start using our shipping calculator today and get accurate quotes for your international shipments.
          </p>
          <Link to="/add-box" className="btn btn-primary btn-large">
            Get Started Now
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;