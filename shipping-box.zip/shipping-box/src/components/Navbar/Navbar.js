// Navigation component with mobile responsive hamburger menu
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import './Navbar.css';

const Navbar = () => {
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  return (
    <nav className="navbar" role="navigation" aria-label="main navigation">
      <div className="navbar-brand">
        <h1 className="navbar-title">
          📦 Shipping Box Calculator
        </h1>
        <p className="navbar-subtitle">
          Calculate shipping costs from India worldwide
        </p>
      </div>

      <div className={`navbar-menu ${isMobileMenuOpen ? 'show' : ''}`}>
        <ul className="navbar-nav">
          <li className="nav-item">
            <Link 
              to="/" 
              className={`nav-link ${location.pathname === '/' ? 'active' : ''}`}
              aria-current={location.pathname === '/' ? 'page' : undefined}
              onClick={closeMobileMenu}
            >
              <span className="nav-icon" aria-hidden="true">🏠</span>
              <span className="nav-text">Home</span>
            </Link>
          </li>

          <li className="nav-item">
            <Link 
              to="/add-box" 
              className={`nav-link ${location.pathname === '/add-box' ? 'active' : ''}`}
              aria-current={location.pathname === '/add-box' ? 'page' : undefined}
              onClick={closeMobileMenu}
            >
              <span className="nav-icon" aria-hidden="true">➕</span>
              <span className="nav-text">Add Box</span>
            </Link>
          </li>

          <li className="nav-item">
            <Link 
              to="/box-list" 
              className={`nav-link ${(location.pathname === '/box-list' || location.pathname === '/boxes') ? 'active' : ''}`}
              aria-current={(location.pathname === '/box-list' || location.pathname === '/boxes') ? 'page' : undefined}
              onClick={closeMobileMenu}
            >
              <span className="nav-icon" aria-hidden="true">📋</span>
              <span className="nav-text">Box List</span>
            </Link>
          </li>
        </ul>
      </div>

      <button 
        className="navbar-toggle"
        aria-label="Toggle navigation menu"
        onClick={toggleMobileMenu}
      >
        <span className="navbar-toggle-icon"></span>
        <span className="navbar-toggle-icon"></span>
        <span className="navbar-toggle-icon"></span>
      </button>
    </nav>
  );
};

export default Navbar;