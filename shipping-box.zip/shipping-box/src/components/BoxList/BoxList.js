// Table component for displaying all shipping boxes with search, filter, and sort
import React, { useEffect, useState } from 'react';
import { useBox } from '../../context/BoxContext';
import { formatCurrency, parseRGBColor, rgbToHex } from '../../utils/shippingCalculator';
import './BoxList.css';

const BoxList = () => {
  const { boxes, loading, error, loadBoxes } = useBox();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCountry, setFilterCountry] = useState('');
  const [sortField, setSortField] = useState('createdAt');
  const [sortDirection, setSortDirection] = useState('desc');

  useEffect(() => {
    loadBoxes();
  }, [loadBoxes]);

  const uniqueCountries = [...new Set(boxes.map(box => box.destination))];

  // Filter and sort logic
  const filteredAndSortedBoxes = boxes
    .filter(box => {
      const matchesSearch = box.receiverName.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCountry = !filterCountry || box.destination === filterCountry;
      return matchesSearch && matchesCountry;
    })
    .sort((a, b) => {
      let aValue = a[sortField];
      let bValue = b[sortField];
      
      if (sortField === 'createdAt') {
        aValue = new Date(aValue);
        bValue = new Date(bValue);
      } else if (sortField === 'weight' || sortField === 'shippingCost') {
        aValue = parseFloat(aValue);
        bValue = parseFloat(bValue);
      } else {
        aValue = String(aValue).toLowerCase();
        bValue = String(bValue).toLowerCase();
      }
      
      if (sortDirection === 'asc') {
        return aValue > bValue ? 1 : -1;
      } else {
        return aValue < bValue ? 1 : -1;
      }
    });

  const handleSort = (field) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const renderColorBox = (colorString) => {
    const rgbColor = parseRGBColor(colorString);
    if (!rgbColor) {
      return (
        <div 
          className="color-box color-box-invalid"
          title="Invalid color format"
          aria-label="Invalid color"
        >
          ?
        </div>
      );
    }

    const hexColor = rgbToHex(rgbColor.r, rgbColor.g, rgbColor.b);
    return (
      <div 
        className="color-box"
        style={{ backgroundColor: hexColor }}
        title={`RGB(${rgbColor.r}, ${rgbColor.g}, ${rgbColor.b})`}
        aria-label={`Color: RGB ${rgbColor.r}, ${rgbColor.g}, ${rgbColor.b}`}
      />
    );
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const clearFilters = () => {
    setSearchTerm('');
    setFilterCountry('');
    setSortField('createdAt');
    setSortDirection('desc');
  };

  // If loading, show loading state
  if (loading) {
    return (
      <div className="box-list-container">
        <div className="loading-state">
          <div className="loading-spinner-large" aria-label="Loading boxes"></div>
          <p>Loading shipping boxes...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="box-list-container">
      <div className="box-list-header">
        <h2 className="box-list-title">📋 Shipping Box List</h2>
        <p className="box-list-description">
          View all your saved shipping boxes with calculated costs
        </p>
      </div>

      <div className="box-list-controls">
        <div className="control-group">
          <label htmlFor="search" className="control-label">Search by name:</label>
          <input
            type="text"
            id="search"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Enter receiver name..."
            className="control-input"
          />
        </div>

        <div className="control-group">
          <label htmlFor="countryFilter" className="control-label">Filter by country:</label>
          <select
            id="countryFilter"
            value={filterCountry}
            onChange={(e) => setFilterCountry(e.target.value)}
            className="control-select"
          >
            <option value="">All countries</option>
            {uniqueCountries.map(country => (
              <option key={country} value={country}>
                {country}
              </option>
            ))}
          </select>
        </div>

        <button
          onClick={clearFilters}
          className="btn btn-clear"
          type="button"
        >
          🔄 Clear Filters
        </button>
      </div>

      {error && (
        <div className="error-message" role="alert">
          {error}
        </div>
      )}

      <div className="results-info">
        <span className="results-count">
          Showing {filteredAndSortedBoxes.length} of {boxes.length} boxes
        </span>
      </div>

      {filteredAndSortedBoxes.length === 0 ? (
        <div className="empty-state">
          <div className="empty-state-icon">📦</div>
          <h3 className="empty-state-title">
            {boxes.length === 0 ? 'No boxes added yet' : 'No boxes match your filters'}
          </h3>
          <p className="empty-state-description">
            {boxes.length === 0 
              ? 'Start by adding your first shipping box using the form.'
              : 'Try adjusting your search criteria or clearing the filters.'
            }
          </p>
        </div>
      ) : (
        <div className="table-container">
          <table className="box-table" role="table" aria-label="Shipping boxes data">
            <thead>
              <tr>
                <th 
                  scope="col"
                  className={`sortable ${sortField === 'receiverName' ? 'active' : ''}`}
                  onClick={() => handleSort('receiverName')}
                  aria-sort={
                    sortField === 'receiverName' 
                      ? (sortDirection === 'asc' ? 'ascending' : 'descending')
                      : 'none'
                  }
                >
                  Receiver Name
                  <span className="sort-icon" aria-hidden="true">
                    {sortField === 'receiverName' ? (sortDirection === 'asc' ? '↑' : '↓') : '↕'}
                  </span>
                </th>

                <th 
                  scope="col"
                  className={`sortable ${sortField === 'weight' ? 'active' : ''}`}
                  onClick={() => handleSort('weight')}
                  aria-sort={
                    sortField === 'weight' 
                      ? (sortDirection === 'asc' ? 'ascending' : 'descending')
                      : 'none'
                  }
                >
                  Weight (kg)
                  <span className="sort-icon" aria-hidden="true">
                    {sortField === 'weight' ? (sortDirection === 'asc' ? '↑' : '↓') : '↕'}
                  </span>
                </th>

                <th scope="col">Box Color</th>

                <th 
                  scope="col"
                  className={`sortable ${sortField === 'destination' ? 'active' : ''}`}
                  onClick={() => handleSort('destination')}
                  aria-sort={
                    sortField === 'destination' 
                      ? (sortDirection === 'asc' ? 'ascending' : 'descending')
                      : 'none'
                  }
                >
                  Destination
                  <span className="sort-icon" aria-hidden="true">
                    {sortField === 'destination' ? (sortDirection === 'asc' ? '↑' : '↓') : '↕'}
                  </span>
                </th>

                <th 
                  scope="col"
                  className={`sortable ${sortField === 'shippingCost' ? 'active' : ''}`}
                  onClick={() => handleSort('shippingCost')}
                  aria-sort={
                    sortField === 'shippingCost' 
                      ? (sortDirection === 'asc' ? 'ascending' : 'descending')
                      : 'none'
                  }
                >
                  Shipping Cost
                  <span className="sort-icon" aria-hidden="true">
                    {sortField === 'shippingCost' ? (sortDirection === 'asc' ? '↑' : '↓') : '↕'}
                  </span>
                </th>

                <th 
                  scope="col"
                  className={`sortable ${sortField === 'createdAt' ? 'active' : ''}`}
                  onClick={() => handleSort('createdAt')}
                  aria-sort={
                    sortField === 'createdAt' 
                      ? (sortDirection === 'asc' ? 'ascending' : 'descending')
                      : 'none'
                  }
                >
                  Date Added
                  <span className="sort-icon" aria-hidden="true">
                    {sortField === 'createdAt' ? (sortDirection === 'asc' ? '↑' : '↓') : '↕'}
                  </span>
                </th>
              </tr>
            </thead>

            <tbody>
              {filteredAndSortedBoxes.map((box, index) => (
                <tr key={box.id} className={index % 2 === 0 ? 'even' : 'odd'}>
                  <td className="receiver-name" data-label="Receiver">
                    {box.receiverName}
                  </td>

                  <td className="weight" data-label="Weight">
                    {box.weight} kg
                  </td>

                  <td className="color-cell" data-label="Color">
                    <div className="color-display">
                      {renderColorBox(box.color)}
                      <span className="color-text">
                        RGB({box.color})
                      </span>
                    </div>
                  </td>

                  <td className="destination" data-label="Destination">
                    <span className="country-flag" aria-hidden="true">
                      {box.destination === 'Sweden' && '🇸🇪'}
                      {box.destination === 'China' && '🇨🇳'}
                      {box.destination === 'Brazil' && '🇧🇷'}
                      {box.destination === 'Australia' && '🇦🇺'}
                    </span>
                    {box.destination}
                  </td>

                  <td className="shipping-cost" data-label="Cost">
                    <span className="cost-amount">
                      {formatCurrency(box.shippingCost)}
                    </span>
                  </td>

                  <td className="date-added" data-label="Date">
                    <time dateTime={box.createdAt}>
                      {formatDate(box.createdAt)}
                    </time>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default BoxList;