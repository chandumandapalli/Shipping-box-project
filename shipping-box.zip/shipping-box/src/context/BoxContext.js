// Global state management for shipping boxes using React Context API
import React, { createContext, useContext, useReducer, useEffect, useCallback } from 'react';
import { boxService } from '../services/boxService';

const BoxContext = createContext();

const initialState = {
  boxes: [],
  loading: false,
  error: null,
};

// Reducer for managing box state updates
function boxReducer(state, action) {
  switch (action.type) {
    case 'SET_LOADING':
      return { ...state, loading: action.payload };
    
    case 'SET_ERROR':
      return { ...state, error: action.payload, loading: false };
    
    case 'SET_BOXES':
      return { ...state, boxes: action.payload, loading: false, error: null };
    
    case 'ADD_BOX':
      return { 
        ...state, 
        boxes: [...state.boxes, action.payload], 
        loading: false, 
        error: null 
      };
    
    case 'CLEAR_ERROR':
      return { ...state, error: null };
    
    default:
      return state;
  }
}

// Provider component that wraps app and provides box data to all children
export function BoxProvider({ children }) {
  const [state, dispatch] = useReducer(boxReducer, initialState);

  const loadBoxes = useCallback(async () => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      const boxes = await boxService.getAllBoxes();
      dispatch({ type: 'SET_BOXES', payload: boxes });
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: 'Failed to load boxes' });
    }
  }, []);

  useEffect(() => {
    loadBoxes();
  }, [loadBoxes]);

  const addBox = useCallback(async (boxData) => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      const newBox = await boxService.saveBox(boxData);
      dispatch({ type: 'ADD_BOX', payload: newBox });
      return { success: true };
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: 'Failed to save box' });
      return { success: false, error: error.message };
    }
  }, []);

  const clearError = useCallback(() => {
    dispatch({ type: 'CLEAR_ERROR' });
  }, []);

  const value = {
    boxes: state.boxes,
    loading: state.loading,
    error: state.error,
    addBox,
    loadBoxes,
    clearError,
  };

  return (
    <BoxContext.Provider value={value}>
      {children}
    </BoxContext.Provider>
  );
}

// Custom hook to use the box context
export function useBox() {
  const context = useContext(BoxContext);
  if (context === undefined) {
    throw new Error('useBox must be used within a BoxProvider');
  }
  return context;
}